# FairyOS Build/Test Three — Screen Companion Autonomy (Privacy-First for Galaxy A16)

This patch turns Spark Baby into a respectful, opt-in screen companion.

## What’s New

- Full Accessibility-based screen awareness (with strong privacy redaction)
- `ScreenPrivacyFilter` that redacts phone numbers, IMEI, IP, MAC, serials, etc.
- Smart positioning and behavior on Samsung Settings / About Phone screens
- Improved overlay that moves intelligently and shows contextual messages
- Clear "Screen Companion Mode" permission card
- No gesture execution (`canPerformGestures="false"`)
- No auto-tapping in this build

## Files Included in This Patch

### New Files
- `ScreenPrivacyFilter.kt`
- `ScreenCompanionPermissionCard.kt`

### Updated Files
- `SparkScreenSenseService.kt`
- `SparkAutonomyBrain.kt`
- `SparkOverlayService.kt`
- `spark_screen_sense_service.xml`
- `strings.xml` (add one string)
- `AndroidManifest.xml` (add service declaration)

## How to Apply

1. Copy the `.kt` files into the correct package folders in your project.
2. Replace `SparkOverlayService.kt` and `SparkScreenSenseService.kt` with the versions in this patch.
3. Add the XML config and update `strings.xml` + `AndroidManifest.xml`.
4. Add the Permission Card composable where you want it (Home screen or Settings recommended).
5. Build with `./gradlew :app:assembleDebug --stacktrace`

## Important Safety Notes for This Build

- Accessibility is completely opt-in
- Password fields are skipped
- Private device info is redacted before the brain sees it
- Spark Baby only **suggests** — she does not tap anything yet
- She moves out of the way when typing fields appear
- She becomes more cautious on Samsung Settings/About Phone pages

This is a safe, demo-ready "screen awareness" layer. The next build can add approved action execution if desired.

---

Apply this patch, test on your A16, and let me know how it feels.