package com.sparkx.fairyos.service

import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import com.sparkx.fairyos.MainActivity
import com.sparkx.fairyos.domain.screen.ScreenSnapshot
import com.sparkx.fairyos.domain.screen.SparkAutonomyBrain
import com.sparkx.fairyos.domain.screen.SparkAutonomyDecision
import com.sparkx.fairyos.domain.screen.SparkOverlayPosition
import kotlin.math.abs
import kotlin.math.max

class SparkOverlayService : Service() {

    private lateinit var windowManager: WindowManager
    private val mainHandler = Handler(Looper.getMainLooper())

    private var overlayView: View? = null
    private var bubbleView: TextView? = null
    private var actionPanel: LinearLayout? = null
    private var messageView: TextView? = null
    private var params: WindowManager.LayoutParams? = null

    private var isUserDragging = false
    private var lastAutoMoveAt = 0L

    private val autonomyListener: (ScreenSnapshot?) -> Unit = { snapshot ->
        val decision = SparkAutonomyBrain.decide(snapshot)
        mainHandler.post { applyAutonomyDecision(decision) }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager

        val container = FrameLayout(this)
        setupOverlayViews(container)

        val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = resources.displayMetrics.widthPixels - dp(120)
            y = dp(140)
        }

        windowManager.addView(container, params)
        overlayView = container

        SparkAutonomyState.addListener(autonomyListener)
    }

    private fun setupOverlayViews(container: FrameLayout) {
        val density = resources.displayMetrics.density

        val rootLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(6), dp(6), dp(6), dp(6))
        }

        messageView = TextView(this).apply {
            text = ""
            visibility = View.GONE
            setTextColor(Color.WHITE)
            textSize = 12f
            maxWidth = dp(230)
            setPadding(dp(10), dp(6), dp(10), dp(6))
            background = roundedBg(Color.argb(220, 18, 20, 35), Color.argb(150, 0, 240, 255), dp(16).toFloat())
        }

        val horizontalRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        bubbleView = TextView(this).apply {
            text = "✦"
            textSize = 28f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            layoutParams = LinearLayout.LayoutParams(dp(58), dp(58))
            background = roundedBg(Color.argb(235, 28, 20, 60), Color.argb(220, 0, 240, 255), dp(29).toFloat())
            elevation = 12f * density
        }

        actionPanel = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            visibility = View.GONE
            setPadding(dp(8), dp(5), dp(8), dp(5))
            background = roundedBg(Color.argb(235, 18, 20, 35), Color.argb(120, 180, 80, 255), dp(18).toFloat())
        }

        actionPanel?.addView(createPanelButton("Open") { launchMainApp(null); collapsePanel() })
        actionPanel?.addView(createPanelButton("Teach") { launchMainApp("teach"); collapsePanel() })
        actionPanel?.addView(createPanelButton("Pause") { SparkAutonomyState.pause(); showMessage("Screen awareness paused."); collapsePanel() })
        actionPanel?.addView(createPanelButton("Resume") { SparkAutonomyState.resume(); showMessage("I’m gently watching again."); collapsePanel() })
        actionPanel?.addView(createPanelButton("Stop") { stopSelf() })

        horizontalRow.addView(bubbleView)
        horizontalRow.addView(actionPanel)

        rootLayout.addView(messageView)
        rootLayout.addView(horizontalRow)
        container.addView(rootLayout)

        wireDragAndTap()
    }

    private fun wireDragAndTap() {
        bubbleView?.setOnTouchListener(object : View.OnTouchListener {
            private var initialX = 0
            private var initialY = 0
            private var initialTouchX = 0f
            private var initialTouchY = 0f
            private var moved = false

            override fun onTouch(v: View?, event: MotionEvent): Boolean {
                val p = params ?: return false
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = p.x; initialY = p.y
                        initialTouchX = event.rawX; initialTouchY = event.rawY
                        moved = false; isUserDragging = true
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val diffX = event.rawX - initialTouchX
                        val diffY = event.rawY - initialTouchY
                        if (abs(diffX) > 8 || abs(diffY) > 8) moved = true
                        p.x = initialX + diffX.toInt()
                        p.y = initialY + diffY.toInt()
                        overlayView?.let { windowManager.updateViewLayout(it, p) }
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        isUserDragging = false
                        if (!moved) togglePanelVisibility()
                        return true
                    }
                }
                return false
            }
        })
    }

    private fun createPanelButton(text: String, onClick: () -> Unit): TextView {
        return TextView(this).apply {
            this.text = text; textSize = 12f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setPadding(dp(10), dp(7), dp(10), dp(7)); setOnClickListener { onClick() }
        }
    }

    private fun applyAutonomyDecision(decision: SparkAutonomyDecision) {
        decision.message?.let { showMessage(it) } ?: hideMessage()
        moveOverlayTo(decision.preferredPosition)
    }

    private fun moveOverlayTo(position: SparkOverlayPosition) {
        if (isUserDragging) return
        val now = System.currentTimeMillis()
        if (now - lastAutoMoveAt < 900L) return
        lastAutoMoveAt = now

        val p = params ?: return
        val metrics = resources.displayMetrics
        val screenW = metrics.widthPixels
        val screenH = metrics.heightPixels
        val rightX = screenW - dp(120)
        val bottomY = screenH - dp(280)

        when (position) {
            SparkOverlayPosition.TOP_RIGHT -> { p.x = rightX; p.y = dp(95) }
            SparkOverlayPosition.TOP_LEFT -> { p.x = dp(24); p.y = dp(95) }
            SparkOverlayPosition.CENTER_RIGHT -> { p.x = rightX; p.y = screenH / 2 }
            SparkOverlayPosition.BOTTOM_RIGHT -> { p.x = rightX; p.y = bottomY }
            SparkOverlayPosition.BOTTOM_LEFT -> { p.x = dp(24); p.y = bottomY }
            SparkOverlayPosition.FLOATING_IDLE -> return
        }
        p.x = p.x.coerceIn(0, max(0, screenW - dp(70)))
        p.y = p.y.coerceIn(0, max(0, screenH - dp(90)))
        overlayView?.let { windowManager.updateViewLayout(it, p) }
    }

    private fun showMessage(message: String) {
        messageView?.text = message
        messageView?.visibility = View.VISIBLE
    }

    private fun hideMessage() {
        messageView?.visibility = View.GONE
    }

    private fun togglePanelVisibility() {
        actionPanel?.let {
            it.visibility = if (it.visibility == View.GONE) View.VISIBLE else View.GONE
        }
    }

    private fun collapsePanel() {
        actionPanel?.visibility = View.GONE
    }

    private fun launchMainApp(screenExtra: String?) {
        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            if (screenExtra != null) putExtra("openScreen", screenExtra)
        }
        startActivity(intent)
    }

    private fun roundedBg(fill: Int, stroke: Int, radius: Float): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = radius
            setColor(fill)
            setStroke(dp(1), stroke)
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        SparkAutonomyState.removeListener(autonomyListener)
        overlayView?.let { runCatching { windowManager.removeView(it) } }
        overlayView = null
        super.onDestroy()
    }
}