package com.sparkx.fairyos.domain.screen

object ScreenPrivacyFilter {

    private val phoneNumberRegex = Regex("""(\+?\d[\d\s\-().]{7,}\d)""")
    private val imeiLikeRegex = Regex("""\b\d{14,17}\b""")
    private val ipRegex = Regex("""\b(?:\d{1,3}\.){3}\d{1,3}\b""")
    private val macRegex = Regex("""\b[0-9A-Fa-f]{2}(:[0-9A-Fa-f]{2}){5}\b""")
    private val longHexIdRegex = Regex("""\b[0-9A-Fa-f]{12,}\b""")

    private val sensitiveLabels = listOf(
        "imei", "eid", "serial number", "phone number",
        "ip address", "mac address", "bluetooth address",
        "baseband", "service provider software version"
    )

    fun shouldSkipLine(text: String): Boolean {
        val lower = text.lowercase()
        return sensitiveLabels.any { lower.contains(it) }
    }

    fun redact(text: String): String {
        var output = text
        output = output.replace(phoneNumberRegex, "[private number]")
        output = output.replace(imeiLikeRegex, "[private device id]")
        output = output.replace(ipRegex, "[private ip]")
        output = output.replace(macRegex, "[private mac]")
        output = output.replace(longHexIdRegex, "[private id]")
        return output
    }

    fun cleanVisibleText(lines: List<String>): List<String> {
        return lines
            .map { it.trim() }
            .filter { it.isNotBlank() }
            .filterNot { shouldSkipLine(it) }
            .map { redact(it) }
            .distinct()
            .take(40)
    }
}