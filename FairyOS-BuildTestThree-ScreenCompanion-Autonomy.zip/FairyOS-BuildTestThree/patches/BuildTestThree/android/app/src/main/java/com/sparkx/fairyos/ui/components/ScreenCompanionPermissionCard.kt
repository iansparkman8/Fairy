package com.sparkx.fairyos.ui.components

import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.sparkx.fairyos.service.SparkAutonomyState
import com.sparkx.fairyos.service.SparkScreenSenseService

@Composable
fun ScreenCompanionPermissionCard(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val isEnabled = remember { isSparkAccessibilityEnabled(context) }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, Color.Cyan.copy(alpha = 0.35f), RoundedCornerShape(18.dp)),
        colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.06f)),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Screen Companion Mode", color = Color.Cyan, fontWeight = FontWeight.Bold)

            Text(
                text = if (isEnabled)
                    "Spark Baby can gently react to what is visible on screen. You stay in control."
                else
                    "Optional: let Spark Baby notice visible text and buttons so she can move out of the way, react, and suggest help.",
                color = Color.White.copy(alpha = 0.78f)
            )

            Text(
                text = "She does not read passwords, capture screenshots, upload your screen, or perform sensitive actions without permission.",
                color = Color.White.copy(alpha = 0.62f)
            )

            if (isEnabled) {
                OutlinedButton(onClick = { SparkAutonomyState.pause() }) {
                    Text("Pause Screen Awareness")
                }
            } else {
                Button(onClick = {
                    context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    })
                }) {
                    Text("Open Accessibility Settings")
                }
            }
        }
    }
}

private fun isSparkAccessibilityEnabled(context: Context): Boolean {
    val expected = "${context.packageName}/${SparkScreenSenseService::class.java.name}"
    val enabledServices = Settings.Secure.getString(
        context.contentResolver,
        Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
    ) ?: return false
    return enabledServices.split(":").any { it.equals(expected, ignoreCase = true) }
}