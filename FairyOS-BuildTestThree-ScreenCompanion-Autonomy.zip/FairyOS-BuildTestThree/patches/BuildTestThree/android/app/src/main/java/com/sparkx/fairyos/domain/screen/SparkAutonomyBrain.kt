package com.sparkx.fairyos.domain.screen

import com.sparkx.fairyos.domain.FairyMood
import java.util.Locale

object SparkAutonomyBrain {

    fun decide(snapshot: ScreenSnapshot?): SparkAutonomyDecision {
        if (snapshot == null) {
            return SparkAutonomyDecision(
                mood = FairyMood.IDLE,
                message = "I'm hanging out with you.",
                preferredPosition = SparkOverlayPosition.FLOATING_IDLE
            )
        }

        val text = snapshot.visibleText.joinToString(" ").lowercase(Locale.ROOT)
        val hasTextField = snapshot.textFields.isNotEmpty()

        // Samsung Settings / About Phone privacy protection
        if (
            snapshot.packageName.contains("settings", ignoreCase = true) ||
            text.contains("about phone") ||
            text.contains("software information") ||
            text.contains("status information") ||
            text.contains("imei") || text.contains("serial number")
        ) {
            return SparkAutonomyDecision(
                mood = FairyMood.ALERT,
                message = "This page may show private phone details. I’ll stay quiet and out of the way.",
                preferredPosition = SparkOverlayPosition.TOP_RIGHT
            )
        }

        if (hasTextField) {
            return SparkAutonomyDecision(
                mood = FairyMood.LISTENING,
                message = "I’ll stay out of your typing space.",
                preferredPosition = SparkOverlayPosition.TOP_RIGHT
            )
        }

        val sendButton = snapshot.buttons.firstOrNull {
            it.label.equals("send", ignoreCase = true) || it.label.equals("send message", ignoreCase = true)
        }

        if (sendButton != null) {
            return SparkAutonomyDecision(
                mood = FairyMood.THINKING,
                message = "I see a Send button. Want me to help review first?",
                preferredPosition = SparkOverlayPosition.CENTER_RIGHT,
                suggestedAction = SparkSuggestedAction("Review first", SparkSuggestedActionType.NONE)
            )
        }

        if (text.contains("error") || text.contains("failed") || text.contains("warning")) {
            return SparkAutonomyDecision(
                mood = FairyMood.ALERT,
                message = "Something looks off. I can help you look at it.",
                preferredPosition = SparkOverlayPosition.TOP_RIGHT
            )
        }

        if (text.contains("code") || text.contains("kotlin") || text.contains("gradle") || text.contains("compose")) {
            return SparkAutonomyDecision(
                mood = FairyMood.THINKING,
                message = "Working on code? Want to save this as an idea?",
                preferredPosition = SparkOverlayPosition.BOTTOM_RIGHT,
                suggestedAction = SparkSuggestedAction("Open Teach & Grow", SparkSuggestedActionType.OPEN_TEACH)
            )
        }

        return SparkAutonomyDecision(
            mood = FairyMood.IDLE,
            message = null,
            preferredPosition = SparkOverlayPosition.FLOATING_IDLE
        )
    }
}