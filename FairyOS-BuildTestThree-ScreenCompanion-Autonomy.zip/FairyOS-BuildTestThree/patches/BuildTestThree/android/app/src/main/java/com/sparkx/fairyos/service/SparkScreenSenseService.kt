package com.sparkx.fairyos.service

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.sparkx.fairyos.domain.screen.ScreenActionTarget
import com.sparkx.fairyos.domain.screen.ScreenPrivacyFilter
import com.sparkx.fairyos.domain.screen.ScreenSnapshot

class SparkScreenSenseService : AccessibilityService() {

    companion object {
        @Volatile var instance: SparkScreenSenseService? = null
            private set
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        SparkAutonomyState.resume()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (!SparkAutonomyState.enabled) return

        val root = rootInActiveWindow ?: return
        val visibleText = mutableListOf<String>()
        val buttons = mutableListOf<ScreenActionTarget>()
        val textFields = mutableListOf<ScreenActionTarget>()

        crawlNode(root, visibleText, buttons, textFields)

        val cleanedText = ScreenPrivacyFilter.cleanVisibleText(visibleText)

        val snapshot = ScreenSnapshot(
            packageName = event?.packageName?.toString().orEmpty(),
            screenTitle = event?.className?.toString(),
            visibleText = cleanedText,
            buttons = buttons.take(30),
            textFields = textFields.take(15)
        )

        SparkAutonomyState.updateSnapshot(snapshot)
    }

    override fun onInterrupt() {
        SparkAutonomyState.pause()
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
        SparkAutonomyState.pause()
    }

    private fun crawlNode(
        node: AccessibilityNodeInfo?,
        visibleText: MutableList<String>,
        buttons: MutableList<ScreenActionTarget>,
        textFields: MutableList<ScreenActionTarget>
    ) {
        if (node == null || node.isPassword) return

        val label = node.text?.toString() ?: node.contentDescription?.toString() ?: ""
        if (label.isNotBlank()) visibleText.add(label)

        val className = node.className?.toString()
        val viewId = node.viewIdResourceName

        if (node.isEditable) {
            textFields.add(ScreenActionTarget(label, className, viewId, node.isClickable, true))
        }

        if (node.isClickable && label.isNotBlank()) {
            buttons.add(ScreenActionTarget(label, className, viewId, true, node.isEditable))
        }

        for (i in 0 until node.childCount) {
            crawlNode(node.getChild(i), visibleText, buttons, textFields)
        }
    }
}