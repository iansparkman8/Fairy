"""
RobotDog module for IPPR Nexus App.
Simple 2D kinematic simulation of a hackable robot dog (Temu/AliExpress base + Raspberry Pi vision).
Intended as mock for the real hardware API (Flask + GPIO servos) discussed in conversations.
"""

import numpy as np
from typing import Dict, List, Tuple, Optional
import math

class RobotDog:
    """
    Kinematic model of a 4-legged robot dog with grippers and head.
    Angles in degrees. Positive = "up/forward" depending on convention.
    """
    def __init__(self):
        # Body
        self.body_x, self.body_y = 400, 320
        self.body_width = 140
        self.body_height = 70
        
        # Leg angles (hip, knee) for each leg. Order: front-left, front-right, back-left, back-right
        # Simplified: each leg has hip_angle and knee_angle
        self.legs = {
            "fl_hip":  -20, "fl_knee": 60,
            "fr_hip":  -20, "fr_knee": 60,
            "bl_hip":   20, "bl_knee": 50,
            "br_hip":   20, "br_knee": 50,
        }
        
        # Head / neck
        self.head_angle = 0   # tilt
        self.neck_length = 45
        
        # Gripper (simple claw on "arm" or front)
        self.gripper_open = 45  # degrees open
        self.gripper_pos = (self.body_x + 60, self.body_y - 30)  # rough
        
        # State
        self.is_walking = False
        self.walk_phase = 0.0
        self.log: List[str] = ["Robot initialized. Ready for API commands."]
        
        # Mock hardware pins / API state
        self.api_state = {"connected": False, "last_command": None}
        
    def set_joint(self, joint: str, angle: float):
        """Set a specific joint angle (clamped)."""
        if joint in self.legs:
            self.legs[joint] = np.clip(angle, -80, 120)
            self.log.append(f"Set {joint} -> {angle:.1f}°")
        elif joint == "head":
            self.head_angle = np.clip(angle, -45, 45)
        elif joint == "gripper":
            self.gripper_open = np.clip(angle, 10, 80)
            
    def get_all_angles(self) -> Dict[str, float]:
        return {**self.legs, "head": self.head_angle, "gripper": self.gripper_open}
    
    def preset(self, name: str):
        """Apply named pose presets."""
        if name == "stand":
            self.legs = {"fl_hip": -25, "fl_knee": 55, "fr_hip": -25, "fr_knee": 55,
                         "bl_hip": 25, "bl_knee": 45, "br_hip": 25, "br_knee": 45}
            self.head_angle = 5
            self.gripper_open = 50
            self.is_walking = False
        elif name == "sit":
            self.legs = {"fl_hip": 30, "fl_knee": 90, "fr_hip": 30, "fr_knee": 90,
                         "bl_hip": -10, "bl_knee": 80, "br_hip": -10, "br_knee": 80}
            self.head_angle = -15
            self.gripper_open = 30
            self.is_walking = False
        elif name == "grab":
            self.legs = {"fl_hip": -40, "fl_knee": 30, "fr_hip": -40, "fr_knee": 30,
                         "bl_hip": 15, "bl_knee": 55, "br_hip": 15, "br_knee": 55}
            self.head_angle = 10
            self.gripper_open = 15  # closed
            self.is_walking = False
        elif name == "walk_ready":
            self.legs = {"fl_hip": -30, "fl_knee": 40, "fr_hip": -10, "fr_knee": 70,
                         "bl_hip": 10, "bl_knee": 70, "br_hip": -30, "br_knee": 40}
            self.head_angle = 0
            self.gripper_open = 45
            self.is_walking = True
            self.walk_phase = 0.0
        self.log.append(f"Preset applied: {name}")
    
    def toggle_walk(self):
        self.is_walking = not self.is_walking
        if self.is_walking:
            self.walk_phase = 0.0
            self.log.append("Walk animation started")
        else:
            self.log.append("Walk animation stopped")
    
    def update_walk(self, dt: float = 0.15):
        """Simple walk cycle animation."""
        if not self.is_walking:
            return
        self.walk_phase += dt
        phase = self.walk_phase * 2 * math.pi
        
        # Front legs alternate with back
        # FL and BR in phase, FR and BL opposite
        self.legs["fl_hip"] = -25 + 15 * math.sin(phase)
        self.legs["fl_knee"] = 50 + 20 * math.sin(phase + 0.5)
        self.legs["fr_hip"] = -25 + 15 * math.sin(phase + math.pi)
        self.legs["fr_knee"] = 50 + 20 * math.sin(phase + math.pi + 0.5)
        
        self.legs["bl_hip"] = 20 + 12 * math.sin(phase + math.pi)
        self.legs["bl_knee"] = 55 + 15 * math.sin(phase + math.pi + 1.0)
        self.legs["br_hip"] = 20 + 12 * math.sin(phase)
        self.legs["br_knee"] = 55 + 15 * math.sin(phase + 1.0)
        
        # Slight head bob
        self.head_angle = 3 * math.sin(phase * 2)
    
    def send_api_command(self, command: str, params: Optional[Dict] = None):
        """Mock sending command to real robot Flask API."""
        params = params or {}
        self.api_state["last_command"] = {"cmd": command, "params": params}
        self.api_state["connected"] = True  # mock
        msg = f"API → /{command} {params}"
        self.log.append(msg)
        return msg
    
    def draw(self, screen, pygame, font_small, font_tiny):
        """Draw the robot on the given pygame surface."""
        # Body (simple rounded rectangle approximation with rect + circles)
        body_rect = pygame.Rect(self.body_x - self.body_width//2, self.body_y - self.body_height//2,
                                self.body_width, self.body_height)
        pygame.draw.rect(screen, (70, 80, 95), body_rect, border_radius=12)
        pygame.draw.rect(screen, (100, 110, 130), body_rect, 3, border_radius=12)  # highlight
        
        # Label
        label = font_tiny.render("IPPR-ROBOT v0.1", True, (180, 200, 220))
        screen.blit(label, (self.body_x - 45, self.body_y - 8))
        
        # Legs - simple line segments (hip -> knee -> foot)
        leg_color = (180, 190, 210)
        foot_color = (220, 180, 100)
        
        leg_defs = [
            ("fl", self.body_x - 50, self.body_y - 10),   # front left attach point
            ("fr", self.body_x + 50, self.body_y - 10),   # front right
            ("bl", self.body_x - 55, self.body_y + 25),   # back left
            ("br", self.body_x + 55, self.body_y + 25),   # back right
        ]
        
        for prefix, ax, ay in leg_defs:
            hip = self.legs.get(f"{prefix}_hip", 0)
            knee = self.legs.get(f"{prefix}_knee", 45)
            
            # Hip to knee
            kx = ax + 35 * math.sin(math.radians(hip))
            ky = ay + 35 * math.cos(math.radians(hip))
            pygame.draw.line(screen, leg_color, (ax, ay), (kx, ky), 6)
            
            # Knee to foot
            fx = kx + 30 * math.sin(math.radians(knee))
            fy = ky + 30 * math.cos(math.radians(knee))
            pygame.draw.line(screen, leg_color, (kx, ky), (fx, fy), 5)
            pygame.draw.circle(screen, foot_color, (int(fx), int(fy)), 7)
        
        # Head / neck
        hx = self.body_x + 70
        hy = self.body_y - 25
        neck_end_x = hx + self.neck_length * math.cos(math.radians(self.head_angle))
        neck_end_y = hy + self.neck_length * math.sin(math.radians(self.head_angle))
        pygame.draw.line(screen, (120, 130, 150), (hx, hy), (neck_end_x, neck_end_y), 8)
        # Head circle
        pygame.draw.circle(screen, (90, 100, 120), (int(neck_end_x), int(neck_end_y)), 18)
        pygame.draw.circle(screen, (60, 70, 90), (int(neck_end_x), int(neck_end_y)), 18, 2)
        # Eye
        eye_x = neck_end_x + 8 * math.cos(math.radians(self.head_angle))
        eye_y = neck_end_y - 5
        pygame.draw.circle(screen, (0, 255, 200), (int(eye_x), int(eye_y)), 5)
        
        # Simple gripper / claw on front (near head)
        gx, gy = neck_end_x + 15, neck_end_y + 10
        pygame.draw.line(screen, (200, 180, 100), (gx, gy), 
                         (gx + 12, gy - self.gripper_open/2), 4)
        pygame.draw.line(screen, (200, 180, 100), (gx, gy), 
                         (gx + 12, gy + self.gripper_open/2), 4)
        
        # Status text
        status = "WALKING" if self.is_walking else "STANDBY"
        color = (0, 255, 100) if self.is_walking else (255, 200, 0)
        status_surf = font_small.render(f"STATUS: {status}", True, color)
        screen.blit(status_surf, (self.body_x - 60, self.body_y + 55))
        
        # Log (last 4 lines)
        y_log = 520
        for i, line in enumerate(self.log[-4:]):
            txt = font_tiny.render(line[:70], True, (150, 160, 180))
            screen.blit(txt, (20, y_log + i * 14))