"""
Music & Creativity Module for IPPR Nexus App.
Contains lyrics and melody generators for songs discussed:
- McKenzie’s Light (father-daughter, 17th birthday)
- Neon Ghost (toxic love / heartbreak)
- Shaky Throne (epic power metal, inner strength / shaky sober hero)
Plus simple procedural melody synthesis using numpy + pygame.
"""

import numpy as np
import io
import wave
from typing import List, Tuple, Optional
import math

# Hardcoded lyrics based on conversation themes (shortened for app display)
LYRICS = {
    "McKenzie’s Light": {
        "theme": "Father to 17-year-old daughter — love, guidance, watching you grow into your own light",
        "lyrics": """[Verse 1]
Seventeen candles, one more year flown
I see the woman you're becoming, and I'm proud to the bone
Through the storms and the silence, through the laughter and tears
You've been my brightest reason for facing my fears

[Chorus]
McKenzie's light, shining so bright
In the darkest of nights, you are my guiding light
No matter where life takes you, no matter how far
You'll always be my shining star, my McKenzie's light

[Verse 2]
I tried to be the shelter when the rain came down
Taught you to stand tall when the world spun around
Now you're spreading your wings, and it hurts but it's right
'Cause the best thing a father can do is let go of the light

[Bridge]
And when you look back on these days that we shared
Know that my love was always there, always there...
"""
    },
    "Neon Ghost": {
        "theme": "Toxic love in a neon-lit city — heartbreak, addiction to the ghost of what was",
        "lyrics": """[Verse 1]
City lights bleeding through the rain on my face
Your memory's a glitch in this digital place
We were fire and ashes, we were poison and wine
Now I'm chasing your shadow through the 3 a.m. signs

[Chorus]
You're my neon ghost, haunting the wires
Flickering lover in the static and fires
I delete your number but you stay in my dreams
Neon ghost, you're tearing me apart at the seams

[Verse 2]
The bars are all empty but the glasses still full
Of the lies that we told when the high was our rule
I tried to get sober from the way that you kiss
But your ghost in the pixels won't let me have this

[Outro]
Fade out in the static... neon ghost...
"""
    },
    "Shaky Throne": {
        "theme": "Epic symphonic power metal — the shaky sober schizophrenic hero fighting inner demons for the throne of self",
        "lyrics": """[Verse 1]
Crown made of static, scepter of shaking hands
The voices are screaming but I still make my stand
They called me unstable, they called me insane
But the fire in my chest still remembers my name

[Chorus]
On this shaky throne I reign!
Through the thunder and the rain!
Demons at the gates, but I will not break
On this shaky throne... I... RISE!

[Verse 2]
The pills couldn't silence what the darkness revealed
So I forged my own armor from the scars that won't heal
Now the kingdom inside me is finally awake
And the voices that haunted me... they bow in my wake

[Bridge - Symphonic]
(Orchestral swell)
RISE! RISE! RISE!
From the ashes of doubt and the chains of the night
RISE! RISE! RISE!
I am sovereign of self in the theater of light!

[Final Chorus]
On this shaky throne I stand tall!
I have answered the call!
No more running, no more fear
The hero is right here... RIGHT HERE!
"""
    }
}


class Song:
    """Simple song container with lyrics and metadata."""
    def __init__(self, title: str, theme: str, lyrics: str):
        self.title = title
        self.theme = theme
        self.lyrics = lyrics
        
    def __repr__(self):
        return f"<Song: {self.title}>"


def get_all_songs() -> List[Song]:
    songs = []
    for title, data in LYRICS.items():
        songs.append(Song(title, data["theme"], data["lyrics"]))
    return songs


def generate_melody(song_title: str, duration: float = 8.0, sample_rate: int = 22050) -> Optional[bytes]:
    """
    Generate a simple procedural melody as WAV bytes for the given song mood.
    Uses numpy to synthesize tones. Returns bytes suitable for pygame.mixer or wave.
    """
    t = np.linspace(0, duration, int(sample_rate * duration), endpoint=False)
    
    if "McKenzie" in song_title:
        # Uplifting major feel - warm, hopeful
        freqs = [261.63, 329.63, 392.00, 523.25]  # C4 E4 G4 C5
        melody = 0.4 * np.sin(2 * np.pi * freqs[0] * t)
        melody += 0.3 * np.sin(2 * np.pi * freqs[1] * t * (1 + 0.01 * np.sin(0.5 * t)))
        melody += 0.25 * np.sin(2 * np.pi * freqs[2] * t)
        # Slow swell
        envelope = 0.6 + 0.4 * np.sin(2 * np.pi * 0.15 * t)
        melody *= envelope
    elif "Neon" in song_title:
        # Minor, tense, glitchy / sad
        freqs = [220.00, 261.63, 329.63, 440.00]  # A3 C4 E4 A4 minor
        melody = 0.5 * np.sin(2 * np.pi * freqs[0] * t)
        melody += 0.35 * np.sin(2 * np.pi * freqs[1] * t * (1 + 0.02 * np.sin(3 * t)))  # slight detune
        melody += 0.2 * np.sin(2 * np.pi * freqs[3] * t * 1.5) * (np.sin(4 * t) > 0)  # staccato
        melody *= (0.7 + 0.3 * np.sin(2 * np.pi * 0.8 * t))  # pulsing
    else:  # Shaky Throne - epic, building power metal
        freqs = [164.81, 207.65, 261.63, 329.63]  # E3 G#3 B3 E4
        melody = 0.6 * np.sin(2 * np.pi * freqs[0] * t)
        melody += 0.4 * np.sin(2 * np.pi * freqs[2] * t)
        # Add power chord like overtones and faster rhythm
        melody += 0.3 * np.sin(2 * np.pi * freqs[3] * t * 2) * (np.sin(8 * t) > -0.5)
        melody *= (0.5 + 0.5 * np.sin(2 * np.pi * 0.4 * t)**2)  # building swell
    
    # Normalize and convert to 16-bit
    melody = np.int16(melody / np.max(np.abs(melody)) * 32767 * 0.9)
    
    # Write to in-memory WAV
    buffer = io.BytesIO()
    with wave.open(buffer, 'wb') as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(sample_rate)
        wf.writeframes(melody.tobytes())
    buffer.seek(0)
    return buffer.read()


def play_melody(pygame_mixer, wav_bytes: bytes):
    """Play the generated melody using pygame.mixer."""
    if wav_bytes is None:
        return
    sound = pygame_mixer.Sound(wav_bytes)
    sound.play()