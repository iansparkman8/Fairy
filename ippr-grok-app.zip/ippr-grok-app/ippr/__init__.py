"""
IPPR Nexus - Infinite Potentiality and Probabilistic Realization Framework
Core package for the IPPR Grok App.

This package contains reusable modules for:
- Theoretical physics models (coherence, constraint, probabilistic realization)
- Cellular automata fingerprints (Rule 110, Game of Life)
- Robot simulation kinematics
- Creative tools (music, parody)

Designed for Ian's collaborative projects with Grok.
"""

from .physics import (
    IPPRModel,
    GameOfLife,
    Rule110CA,
    compute_fingerprint,
    sp_model_rotation_curve
)
from .robot import RobotDog
from .music import Song, generate_melody

__version__ = "0.1.0"
__author__ = "Ian + Grok (IPPR Nexus Project)"
__all__ = ["IPPRModel", "GameOfLife", "Rule110CA", "RobotDog", "Song", "generate_melody"]