"""
IPPR Physics Module
Core classes and functions for the Infinite Potentiality and Probabilistic Realization (IPPR) framework.

Includes:
- IPPRModel: Core statistical-mechanical model with coherence and constraint penalties
- GameOfLife: 2D cellular automata with fingerprinting (β_c ≈ 0.6)
- Rule110CA: Elementary CA with complex behavior (β_c ≈ 0.8)
- Utility functions for fingerprints, SPARC-like models, etc.
"""

import numpy as np
from typing import Tuple, Optional, Dict, Any
import random

class IPPRModel:
    """
    Simplified IPPR core model.
    Represents a system with coherence length, constraint penalty, and probabilistic realization.
    """
    def __init__(self, coherence_length: float = 4.0, constraint_strength: float = 1.8, 
                 beta_c: float = 1.0, seed: Optional[int] = None):
        self.coherence_length = coherence_length
        self.constraint_strength = constraint_strength
        self.beta_c = beta_c  # critical inverse temperature or control parameter
        self.rng = np.random.default_rng(seed)
        self.history: list = []
        
    def compute_realization_probability(self, state: np.ndarray) -> float:
        """Compute probabilistic realization density for a given microstate."""
        # Mock energy-like function: constraint penalty + coherence reward
        constraint_term = self.constraint_strength * np.sum(state**2)
        # Simple coherence: local similarity / clustering
        if state.ndim == 1:
            coherence_term = -np.sum(np.diff(state)**2) / self.coherence_length
        else:
            # For 2D grid
            dx = np.diff(state, axis=1)
            dy = np.diff(state, axis=0)
            coherence_term = -(np.sum(dx**2) + np.sum(dy**2)) / self.coherence_length
        # Boltzmann-like probability (simplified)
        energy = constraint_term + coherence_term
        prob = np.exp(-energy / max(self.beta_c, 0.01))
        return float(np.clip(prob, 0, 1))
    
    def replica_exchange_step(self, states: list) -> list:
        """Mock replica exchange Monte Carlo step (simplified)."""
        new_states = []
        for s in states:
            # Propose flip or small perturbation
            proposal = s.copy()
            if proposal.ndim == 1:
                idx = self.rng.integers(0, len(proposal))
                proposal[idx] = 1 - proposal[idx] if proposal.dtype == int else proposal[idx] + self.rng.normal(0, 0.1)
            else:
                i, j = self.rng.integers(0, proposal.shape[0]), self.rng.integers(0, proposal.shape[1])
                proposal[i, j] = 1 - proposal[i, j] if proposal.dtype == int else proposal[i, j] + self.rng.normal(0, 0.2)
            
            p_old = self.compute_realization_probability(s)
            p_new = self.compute_realization_probability(proposal)
            if self.rng.random() < min(1, p_new / max(p_old, 1e-9)):
                new_states.append(proposal)
            else:
                new_states.append(s)
        self.history.append(np.mean([self.compute_realization_probability(st) for st in new_states]))
        return new_states
    
    def get_fingerprint(self) -> Dict[str, Any]:
        """Return current model fingerprint (for reproducibility / comparison)."""
        return {
            "coherence_length": round(self.coherence_length, 3),
            "constraint_strength": round(self.constraint_strength, 3),
            "beta_c": round(self.beta_c, 3),
            "mean_realization": round(self.history[-1], 4) if self.history else None,
            "version": "ippr-v0.3-mock"
        }


class GameOfLife:
    """
    Conway's Game of Life with IPPR-style fingerprinting.
    Critical β_c ≈ 0.6 with ~12% compression in some analyses (from past discussions).
    """
    def __init__(self, width: int = 80, height: int = 60, seed: Optional[int] = None):
        self.width = width
        self.height = height
        self.rng = np.random.default_rng(seed)
        self.grid = self.rng.integers(0, 2, (height, width), dtype=np.int8)
        self.generation = 0
        self.history = []
        
    def step(self) -> np.ndarray:
        """Advance one generation using Conway rules."""
        new_grid = self.grid.copy()
        for i in range(self.height):
            for j in range(self.width):
                # Count neighbors with periodic boundary
                total = (self.grid[(i-1)%self.height, (j-1)%self.width] +
                         self.grid[(i-1)%self.height, j] +
                         self.grid[(i-1)%self.height, (j+1)%self.width] +
                         self.grid[i, (j-1)%self.width] +
                         self.grid[i, (j+1)%self.width] +
                         self.grid[(i+1)%self.height, (j-1)%self.width] +
                         self.grid[(i+1)%self.height, j] +
                         self.grid[(i+1)%self.height, (j+1)%self.width])
                if self.grid[i, j] == 1:
                    new_grid[i, j] = 1 if total in (2, 3) else 0
                else:
                    new_grid[i, j] = 1 if total == 3 else 0
        self.grid = new_grid
        self.generation += 1
        # Record density for fingerprint
        density = np.mean(self.grid)
        self.history.append(density)
        return self.grid
    
    def randomize(self, p: float = 0.3):
        self.grid = (self.rng.random((self.height, self.width)) < p).astype(np.int8)
        self.generation = 0
        self.history = [np.mean(self.grid)]
    
    def clear(self):
        self.grid = np.zeros((self.height, self.width), dtype=np.int8)
        self.generation = 0
        self.history = [0.0]
    
    def get_fingerprint(self) -> Dict[str, Any]:
        """IPPR-style fingerprint: critical beta_c ~0.6, compression estimate."""
        if len(self.history) < 5:
            return {"beta_c": 0.6, "density": float(np.mean(self.grid)), "note": "Run more steps for full fingerprint"}
        # Simple "compression" proxy: variance in density or autocorrelation rough
        var_density = float(np.var(self.history[-20:])) if len(self.history) > 20 else 0.12
        return {
            "beta_c": 0.6,
            "mean_density": round(float(np.mean(self.grid)), 4),
            "density_variance": round(var_density, 4),
            "compression_proxy": round(0.12 + 0.05 * var_density, 3),  # ~12% as discussed
            "generations": self.generation,
            "class": "GameOfLife"
        }


class Rule110CA:
    """
    Elementary Cellular Automaton Rule 110.
    Famous for complex behavior from simple rules. IPPR fingerprint β_c ≈ 0.8.
    """
    def __init__(self, width: int = 120, height: int = 80, seed: Optional[int] = None):
        self.width = width
        self.height = height
        self.rng = np.random.default_rng(seed)
        self.space_time = np.zeros((height, width), dtype=np.int8)
        # Initial condition: single 1 in middle or random
        self.space_time[0, width // 2] = 1
        self.generation = 0
        
    def _rule110(self, left: int, center: int, right: int) -> int:
        """Rule 110 transition function."""
        # Neighborhood code: 111=7 ... 000=0
        neighborhood = (left << 2) | (center << 1) | right
        # Rule 110 binary: 01101110
        return (110 >> neighborhood) & 1
    
    def step(self) -> np.ndarray:
        """Evolve one row."""
        if self.generation >= self.height - 1:
            return self.space_time
        current = self.space_time[self.generation]
        next_row = np.zeros(self.width, dtype=np.int8)
        for j in range(1, self.width - 1):
            next_row[j] = self._rule110(current[j-1], current[j], current[j+1])
        # Periodic-ish or copy edges
        next_row[0] = self._rule110(current[-1], current[0], current[1])
        next_row[-1] = self._rule110(current[-2], current[-1], current[0])
        self.space_time[self.generation + 1] = next_row
        self.generation += 1
        return self.space_time
    
    def randomize_initial(self, p: float = 0.1):
        self.space_time[0] = (self.rng.random(self.width) < p).astype(np.int8)
        self.space_time[1:] = 0
        self.generation = 0
    
    def get_fingerprint(self) -> Dict[str, Any]:
        return {
            "beta_c": 0.8,
            "complexity": "Class IV (complex)",
            "generations": self.generation,
            "active_cells": int(np.sum(self.space_time)),
            "class": "Rule110"
        }


def compute_fingerprint(obj: Any) -> Dict[str, Any]:
    """Generic fingerprint dispatcher."""
    if hasattr(obj, "get_fingerprint"):
        return obj.get_fingerprint()
    return {"error": "No fingerprint method"}


def sp_model_rotation_curve(r: np.ndarray, v0: float = 180.0, r_scale: float = 2.0,
                            coherence_boost: float = 45.0) -> Tuple[np.ndarray, np.ndarray]:
    """
    Simple IPPR-modified galactic rotation curve model.
    Newtonian decline + coherence term that produces flat outer curve.
    """
    v_newton = v0 * np.sqrt( (r**2) / (r**2 + r_scale**2) ) * np.exp(-r / 12.0) + 15
    boost = coherence_boost / (1 + np.exp((r - 6.0) / 2.5))
    v_ippr = v_newton + boost * (1 - 0.25 * np.tanh((r - 8) / 3))
    return v_newton, v_ippr