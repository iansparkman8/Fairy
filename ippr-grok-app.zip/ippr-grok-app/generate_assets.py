#!/usr/bin/env python3
"""
Generate static assets (plots, images) for the IPPR Grok App.
Run this once before launching the main app.
"""

import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib
matplotlib.use('Agg')  # headless
from PIL import Image, ImageDraw, ImageFont, ImageFilter
import math

ASSETS_DIR = os.path.join(os.path.dirname(__file__), "assets")
os.makedirs(ASSETS_DIR, exist_ok=True)

# Color theme - cosmic dark with neon accents
BG_COLOR = "#0a0a1f"
ACCENT_CYAN = "#00f0ff"
ACCENT_GREEN = "#39ff14"
ACCENT_PURPLE = "#c000ff"
ACCENT_ORANGE = "#ff9500"
TEXT_WHITE = "#e0e0ff"

def create_logo():
    """Create a stylized logo image for IPPR Nexus"""
    width, height = 800, 300
    img = Image.new('RGBA', (width, height), (10, 10, 31, 255))
    draw = ImageDraw.Draw(img)
    
    # Try to use a nice font, fallback to default
    try:
        font_large = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 72)
        font_small = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 28)
    except:
        font_large = ImageFont.load_default()
        font_small = ImageFont.load_default()
    
    # Draw glowing orbs / particles for "infinite potentiality"
    np.random.seed(42)
    for _ in range(80):
        x = np.random.randint(50, width-50)
        y = np.random.randint(30, height-30)
        r = np.random.randint(1, 6)
        alpha = np.random.randint(50, 200)
        color = (0, 240, 255, alpha) if np.random.random() > 0.5 else (57, 255, 20, alpha)
        draw.ellipse([x-r, y-r, x+r, y+r], fill=color)
    
    # Main title
    title = "IPPR NEXUS"
    bbox = draw.textbbox((0, 0), title, font=font_large)
    tw = bbox[2] - bbox[0]
    draw.text(((width - tw) // 2, 60), title, font=font_large, fill=ACCENT_CYAN)
    
    # Subtitle
    subtitle = "Infinite Potentiality • Embodied Probabilities • Creative Realization"
    bbox2 = draw.textbbox((0, 0), subtitle, font=font_small)
    tw2 = bbox2[2] - bbox2[0]
    draw.text(((width - tw2) // 2, 160), subtitle, font=font_small, fill=ACCENT_GREEN)
    
    # Decorative line
    draw.line([(100, 220), (width-100, 220)], fill=ACCENT_PURPLE, width=3)
    
    # Tagline
    tag = "Physics • Robotics • Music • Memory"
    bbox3 = draw.textbbox((0, 0), tag, font=font_small)
    tw3 = bbox3[2] - bbox3[0]
    draw.text(((width - tw3) // 2, 240), tag, font=font_small, fill=TEXT_WHITE)
    
    img.save(os.path.join(ASSETS_DIR, "logo.png"), "PNG")
    print("Created logo.png")


def create_sparc_plot():
    """Mock SPARC galactic rotation curve with IPPR reinterpretation"""
    fig, ax = plt.subplots(figsize=(10, 6), facecolor=BG_COLOR)
    ax.set_facecolor(BG_COLOR)
    
    r = np.linspace(0.1, 15, 300)
    
    # Mock Newtonian (Keplerian decline after peak)
    v_newton = 180 * np.sqrt( (r**2) / (r**2 + 2**2) ) * np.exp(-r / 12) + 20
    
    # IPPR modified: adds a coherence term that flattens the curve at large r
    # Simple model: extra velocity component ~ 1 / (1 + exp((r - r0)/width)) or coherence penalty inverse
    coherence_boost = 45 / (1 + np.exp((r - 6) / 2.5))
    v_ippr = v_newton + coherence_boost * (1 - 0.3 * np.tanh((r-8)/3))
    
    # Add some realistic scatter / uncertainty
    np.random.seed(7)
    v_obs = v_ippr + np.random.normal(0, 8, len(r))
    
    ax.plot(r, v_newton, '--', color='#ff6b6b', linewidth=2.5, label='Newtonian (no dark matter)', alpha=0.8)
    ax.plot(r, v_ippr, color=ACCENT_CYAN, linewidth=3, label='IPPR Coherence Model (this work)')
    ax.scatter(r[::8], v_obs[::8], c=ACCENT_GREEN, s=25, alpha=0.7, label='SPARC-like observations (mock)', zorder=5)
    
    ax.set_xlabel('Radius (kpc)', color=TEXT_WHITE, fontsize=12)
    ax.set_ylabel('Rotation Velocity (km/s)', color=TEXT_WHITE, fontsize=12)
    ax.set_title('SPARC Galaxy Rotation Curves — IPPR Reinterpretation\n(Flat outer curve via probabilistic coherence, not exotic dark matter)', 
                 color=TEXT_WHITE, fontsize=14, pad=15)
    
    ax.tick_params(colors=TEXT_WHITE)
    for spine in ax.spines.values():
        spine.set_color('#444466')
    
    ax.legend(loc='upper right', facecolor='#1a1a2e', edgecolor='#444466', labelcolor=TEXT_WHITE)
    ax.grid(True, alpha=0.2, color='white')
    ax.set_xlim(0, 15)
    ax.set_ylim(0, 250)
    
    plt.tight_layout()
    plt.savefig(os.path.join(ASSETS_DIR, "sparc_curve.png"), dpi=150, facecolor=BG_COLOR, edgecolor='none')
    plt.close()
    print("Created sparc_curve.png")


def create_dark_energy_plot():
    """Mock DESI-inspired evolving dark energy with phantom crossing"""
    fig, ax = plt.subplots(figsize=(10, 6), facecolor=BG_COLOR)
    ax.set_facecolor(BG_COLOR)
    
    z = np.linspace(0, 2.5, 400)
    
    # Simple parametrization w(z) = w0 + wa * z / (1+z)  (CPL form)
    # Example values inspired by DESI DR2 hints: w0 ≈ -0.75, wa ≈ -0.8 or so for phantom cross
    w0 = -0.82
    wa = -0.75
    w_z = w0 + wa * z / (1 + z)
    
    # Phantom divide line
    ax.axhline(y=-1, color='#ff4757', linestyle='--', linewidth=2, alpha=0.7, label='Phantom divide (w = -1)')
    
    ax.plot(z, w_z, color=ACCENT_PURPLE, linewidth=3, label=r'IPPR + DESI-inspired $w(z)$ (phantom crossing ~z=0.5)')
    
    # Mock uncertainty band
    w_err = 0.08 + 0.04 * z
    ax.fill_between(z, w_z - w_err, w_z + w_err, color=ACCENT_PURPLE, alpha=0.15, label='1σ uncertainty (mock)')
    
    # Highlight crossing
    cross_z = 0.48
    ax.axvline(x=cross_z, color=ACCENT_ORANGE, linestyle=':', linewidth=2, alpha=0.8)
    ax.annotate('Phantom crossing\n(z≈0.5)', xy=(cross_z, -1.05), xytext=(cross_z+0.3, -1.25),
                fontsize=10, color=ACCENT_ORANGE,
                arrowprops=dict(arrowstyle='->', color=ACCENT_ORANGE))
    
    ax.set_xlabel('Redshift z', color=TEXT_WHITE, fontsize=12)
    ax.set_ylabel(r'Equation of State $w(z)$', color=TEXT_WHITE, fontsize=12)
    ax.set_title('Dark Energy Evolution — IPPR Multi-Sector Model\n(Integrating DESI DR2 hints of evolving / phantom dark energy)', 
                 color=TEXT_WHITE, fontsize=13, pad=15)
    
    ax.tick_params(colors=TEXT_WHITE)
    for spine in ax.spines.values():
        spine.set_color('#444466')
    
    ax.legend(loc='lower left', facecolor='#1a1a2e', edgecolor='#444466', labelcolor=TEXT_WHITE, fontsize=9)
    ax.grid(True, alpha=0.2, color='white')
    ax.set_xlim(0, 2.5)
    ax.set_ylim(-1.6, -0.4)
    
    plt.tight_layout()
    plt.savefig(os.path.join(ASSETS_DIR, "dark_energy.png"), dpi=150, facecolor=BG_COLOR, edgecolor='none')
    plt.close()
    print("Created dark_energy.png")


def create_coherence_plot():
    """IPPR coherence / constraint / probabilistic realization landscape"""
    fig, ax = plt.subplots(figsize=(10, 7), facecolor=BG_COLOR)
    ax.set_facecolor(BG_COLOR)
    
    # 2D parameter space: constraint strength vs coherence length
    constraint = np.linspace(0.1, 5, 200)
    coherence_len = np.linspace(0.5, 8, 200)
    C, L = np.meshgrid(constraint, coherence_len)
    
    # Mock "realization probability" or effective potential / order parameter
    # Higher probability in certain regime (valley of realization)
    prob = np.exp( - (C - 1.8)**2 / 1.5 - (L - 4.2)**2 / 6 ) * (1 + 0.4 * np.sin(C*2) * np.cos(L))
    prob = np.clip(prob, 0, 1)
    
    im = ax.contourf(C, L, prob, levels=25, cmap='plasma')  # plasma for cosmic feel
    cbar = plt.colorbar(im, ax=ax, shrink=0.8)
    cbar.set_label('Probabilistic Realization Density', color=TEXT_WHITE, fontsize=10)
    cbar.ax.yaxis.set_tick_params(color=TEXT_WHITE)
    plt.setp(cbar.ax.get_yticklabels(), color=TEXT_WHITE)
    
    # Mark interesting points (e.g. critical beta_c from memory: GoL ~0.6, ECA ~0.8)
    ax.plot(1.2, 3.5, 'o', markersize=12, color=ACCENT_CYAN, markeredgecolor='white', label=r'ECA-110 critical ($\beta_c \approx 0.8$)')
    ax.plot(2.5, 2.8, 's', markersize=11, color=ACCENT_GREEN, markeredgecolor='white', label=r'Game of Life critical ($\beta_c \approx 0.6$)')
    ax.plot(3.8, 5.5, '^', markersize=12, color=ACCENT_ORANGE, markeredgecolor='white', label='SPARC best-fit region')
    
    ax.set_xlabel('Constraint Penalty Strength', color=TEXT_WHITE, fontsize=12)
    ax.set_ylabel('Coherence Length Scale', color=TEXT_WHITE, fontsize=12)
    ax.set_title('IPPR Framework: Coherence-Constraint Landscape\n(Probabilistic Realization Density — where structure emerges from potentiality)', 
                 color=TEXT_WHITE, fontsize=13, pad=15)
    
    ax.tick_params(colors=TEXT_WHITE)
    for spine in ax.spines.values():
        spine.set_color('#444466')
    
    ax.legend(loc='upper right', facecolor='#1a1a2e', edgecolor='#444466', labelcolor=TEXT_WHITE, fontsize=9)
    
    plt.tight_layout()
    plt.savefig(os.path.join(ASSETS_DIR, "coherence_landscape.png"), dpi=150, facecolor=BG_COLOR, edgecolor='none')
    plt.close()
    print("Created coherence_landscape.png")


def create_cellular_automata_preview():
    """Simple preview image of Game of Life / Rule 110 patterns"""
    fig, axes = plt.subplots(1, 2, figsize=(12, 5), facecolor=BG_COLOR)
    
    np.random.seed(123)
    
    # Simple Game of Life-ish pattern (glider-ish or random)
    grid_gol = np.random.randint(0, 2, (60, 80))
    # Run a few steps manually for preview
    for _ in range(8):
        new_grid = grid_gol.copy()
        for i in range(1, grid_gol.shape[0]-1):
            for j in range(1, grid_gol.shape[1]-1):
                neighbors = np.sum(grid_gol[i-1:i+2, j-1:j+2]) - grid_gol[i, j]
                if grid_gol[i, j] == 1 and neighbors not in (2, 3):
                    new_grid[i, j] = 0
                elif grid_gol[i, j] == 0 and neighbors == 3:
                    new_grid[i, j] = 1
        grid_gol = new_grid
    
    axes[0].imshow(grid_gol, cmap='Greens', interpolation='nearest')
    axes[0].set_title("Conway's Game of Life (IPPR fingerprint β_c ≈ 0.6)", color=TEXT_WHITE, fontsize=11)
    axes[0].axis('off')
    
    # Rule 110 simple 1D CA evolution preview (space-time diagram)
    width = 120
    height = 70
    rule110 = np.zeros((height, width), dtype=int)
    rule110[0, width//2] = 1  # single seed
    
    def rule110_step(cells):
        new = np.zeros_like(cells)
        for i in range(1, len(cells)-1):
            # Rule 110: 01101110 in binary for neighborhoods 111 to 000
            # Simple impl
            p = (cells[i-1] << 2) | (cells[i] << 1) | cells[i+1]
            new[i] = (110 >> p) & 1   # wait, correct bit order? approx
        return new
    
    # Actually implement elementary CA correctly
    for t in range(1, height):
        rule110[t] = rule110_step(rule110[t-1])
    
    axes[1].imshow(rule110, cmap='Blues', interpolation='nearest')
    axes[1].set_title("Rule 110 Elementary CA (IPPR fingerprint β_c ≈ 0.8, complex behavior)", color=TEXT_WHITE, fontsize=11)
    axes[1].axis('off')
    
    plt.suptitle("IPPR Cellular Automata Fingerprints — Emergence & Complexity", color=ACCENT_CYAN, fontsize=14, y=1.02)
    plt.tight_layout()
    plt.savefig(os.path.join(ASSETS_DIR, "ca_preview.png"), dpi=140, facecolor=BG_COLOR, edgecolor='none')
    plt.close()
    print("Created ca_preview.png")


if __name__ == "__main__":
    print("Generating IPPR Nexus assets...")
    create_logo()
    create_sparc_plot()
    create_dark_energy_plot()
    create_coherence_plot()
    create_cellular_automata_preview()
    print("\nAll assets generated successfully in", ASSETS_DIR)